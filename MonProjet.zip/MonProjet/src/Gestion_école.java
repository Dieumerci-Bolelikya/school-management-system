/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PC
 * import java.util.Arraylist;
 
public class Gestion {
    public void Eleve(){
        boolean inscrit = true;
        
        if(inscrit){
            System.out.println("Eleve inscrit");
        }else{
            System.out.println("Eleve non inscrit");
        }
      
            
        }
         class Paiement{
            private String date;
            private String numberEleve;
        public Paiement(String date,String numberElève){
            this.numberEleve = numberElève;
            this.date = date; 
            
        }
        class Note{
            private String quantiteTravail;
            private String nomEleve;
            private  double maxima;
            private double pointObtenu;
            
        
        public Note (String Quantite_travail,String nom_Elève,double maxima,double pointObtenu){
                this.quantiteTravail = quantiteTravail;
                this.nomEleve = nomEleve;
                this.maxima = maxima;
                this.pointObtenu = pointObtenu;
        }
                public double getMaxima(){
                    return maxima;
                }
                public double getpointObtenu(){
                    return pointObtenu;
                }
                public String getquantiteTravail(){
                    return quantiteTravail;
                }
        }
        class Bulletin {
            private String nomEleve;
            private ArrayList<Note> listeNotes;
            
            public Bulletin(String nomEleve){
                this.nomEleve = nomEleve;
                this.listeNotes = new ArrayList<>();
                
            }
            public void ajouterNote(Note note){
                listeNotes.add(note);
            }
            public double calculerMoyenne(){
                double totalPoints = 0;
                double totalMax = 0;
                for(Note n : listeNotes){
                    totalPoints += n.getpointObtenu();
                    totalMax += n.getMaxima();
                }
                return(totalPoints/ totalMax) * 20;
            }
            public void afficherBulletin(){
                System.out.println("Bulletin de: "+nomEleve);
                for (Note n:listeNotes){
                    System.out.println(n.getquantiteTravail()+ ":"+n.getpointObtenu()+ "/"+n.getMaxima());
                }
                System.out.println("Moyenne :"+ calculerMoyenne());
            }
            }
        public static void main (String[] args){
            Gestion gestion = new Gestion();
            
            Bulletin bulletin = gestion.new Bulletin ("TOI");
            Note f= gestion.new Note("Total",20,15);
            bulletin.ajouterNote(f);
            bulletin.afficherBulletin();
        }
        }
    
}
